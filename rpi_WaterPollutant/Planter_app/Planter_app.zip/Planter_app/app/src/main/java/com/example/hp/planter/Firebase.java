package com.example.hp.planter;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Firebase {

    public static DatabaseReference mDatabase  = FirebaseDatabase.getInstance().getReference();
    public static DatabaseReference motor  = mDatabase.child("motor");
    public static DatabaseReference moisture_sensor = mDatabase.child("moisture_sensor");


    public static void setMotor(DatabaseReference motor) {

        Firebase.motor = motor;
    }

    public static void setMoisture_sensor(boolean b) {
        moisture_sensor.setValue(1);
    }

    public  DatabaseReference getmDatabase() {
        return mDatabase;
    }

    public DatabaseReference getmotor() {
        return motor;
    }

    public DatabaseReference getMoisture_sensor() {
        return moisture_sensor;
    }



}
