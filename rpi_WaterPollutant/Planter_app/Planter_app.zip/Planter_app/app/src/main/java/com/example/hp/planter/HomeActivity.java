package com.example.hp.planter;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import com.google.firebase.FirebaseApp;
import com.google.android.things.pio.Gpio;
import com.google.android.things.pio.GpioCallback;
import com.google.android.things.pio.PeripheralManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;

import static android.content.ContentValues.TAG;

/**
 * Skeleton of an Android Things activity.
 * <p>
 * Android Things peripheral APIs are accessible through the class
 * PeripheralManagerService. For example, the snippet below will open a GPIO pin and
 * set it to HIGH:
 * <p>
 * <pre>{@code
 * PeripheralManagerService service = new PeripheralManagerService();
 * mLedGpio = service.openGpio("BCM6");
 * mLedGpio.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);
 * mLedGpio.setValue(true);
 * }</pre>
 * <p>
 * For more complex peripherals, look for an existing user-space driver, or implement one if none
 * is available.
 *
 * @see <a href="https://github.com/androidthings/contrib-drivers#readme">https://github.com/androidthings/contrib-drivers#readme</a>
 */
public class HomeActivity extends Activity {

    private static final String Pin_motor = "BCM4";
    private static final String Pin_moisture_sensor= "BCM17";
    private Gpio Gpio_motor;
    private Gpio Gpio_moisture_sensor;
    public  DatabaseReference mDatabase  = FirebaseDatabase.getInstance().getReference();
    public  DatabaseReference motor  = mDatabase.child("motor");
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);

        PeripheralManager service = PeripheralManager.getInstance();
        try {
            Gpio_moisture_sensor = service.openGpio(Pin_moisture_sensor);
            Gpio_moisture_sensor.setDirection(Gpio.DIRECTION_IN);
            Gpio_moisture_sensor.setEdgeTriggerType(Gpio.EDGE_BOTH);
            Gpio_moisture_sensor.registerGpioCallback(mSetOutterApplianceCallBack);

            Gpio_motor = service.openGpio(Pin_motor);
            Gpio_motor.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);

        }catch (IOException e){
            Log.e(TAG, "Error on PeripheralIO API", e);
        }


    }

   private GpioCallback mSetOutterApplianceCallBack = new GpioCallback() {
       @Override
       public boolean onGpioEdge(Gpio gpio) {
           if(gpio == null){
               return true;
           }
           setGpio_moisture_sensor(gpio);
           return true;
       }
   };

    private void setGpio_moisture_sensor(Gpio gpio){

        try {
            if(gpio.getValue() == true){
                Firebase.setMoisture_sensor(true);
            }else {
                Firebase.setMoisture_sensor(false);
            }
        } catch (IOException e) {
            Log.e(TAG, "Error on setting the value of moisture sensor at line 86 in main activity", e);
        }


    }

    @Override
    protected void onStart() {
        super.onStart();

        motor.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Integer mmotor = dataSnapshot.getValue(Integer.class);
                try {
                    change_motor_state(mmotor,Gpio_motor);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public void change_motor_state(Integer state, Gpio motor) throws IOException {
        if(motor != null){
            if(state == 1){
                motor.setValue(true);
            }else {
                motor.setValue(false);
            }
        }


    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (Gpio_moisture_sensor != null) {
            Gpio_moisture_sensor.unregisterGpioCallback(mSetOutterApplianceCallBack);
            try {
                Gpio_moisture_sensor.close();
            } catch (IOException e) {
                Log.e(TAG, "Error on PeripheralIO API", e);
            }
        }
    }
}
